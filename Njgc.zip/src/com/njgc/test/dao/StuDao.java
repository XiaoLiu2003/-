package com.njgc.test.dao;

import java.util.List;

import com.njgc.test.model.Stu;

public interface StuDao {

	public Stu getStuByStuId(String stuId);

	public int insertStu(Stu stu);

	public List<Stu> getAllStuList();

	public List<Stu> getStuListByStuName(String stuName);

	public int updateStu(Stu stu);

	public int deleteStu(String stuId);

}
