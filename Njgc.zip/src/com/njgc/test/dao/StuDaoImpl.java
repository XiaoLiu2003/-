package com.njgc.test.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import com.njgc.test.model.Stu;
import com.mchange.v2.c3p0.ComboPooledDataSource;
//数据库的增删改查
public class StuDaoImpl implements StuDao{
	static Connection conn= null;
	static{
		try {
			ComboPooledDataSource ds = new ComboPooledDataSource();
			conn = ds.getConnection();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	@Override
	public Stu getStuByStuId(String stuId) {
		Stu stu =null;
		try {		
			String sql = "select*from student where stuId=?";
			PreparedStatement prep = conn.prepareStatement(sql);
			prep.setString(1,stuId);
			ResultSet rs = prep.executeQuery();//返回查询结果
			while(rs.next()) {
				stu = new Stu();
				stu.setStuId(rs.getString("stuId"));
				stu.setStuName(rs.getString("stuName"));
				stu.setStuSubject(rs.getString("StuSubject"));
				stu.setStuAge(rs.getInt("stuAge"));			
				stu.setStuMajor(rs.getString("StuMajor"));
				
			}
		} catch (SQLException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		
		return stu;
	}

	@Override
	public int insertStu(Stu stu) {
		int flag = 0;
		try {
			PreparedStatement prep = conn.prepareStatement("insert into student(stuId,stuName,stuSubject,stuAge,stuMajor) values(?,?,?,?,?)");
			prep.setString(1, stu.getStuId());
			prep.setString(2, stu.getStuName());
			prep.setString(3, stu.getStuSubject());			
			prep.setInt(4, stu.getStuAge());
			prep.setString(5, stu.getStuMajor());
			flag = prep.executeUpdate();
			
			
		} catch (SQLException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		return flag;
	}

	@Override
	public List<Stu> getAllStuList() {
		
		
		List<Stu> list = new ArrayList<>();
		try {
			Statement statement = conn.createStatement();
			ResultSet rs = statement.executeQuery("select*from student");
			while(rs.next()) {
			Stu stu = new Stu();
			stu.setStuId(rs.getString("stuId"));
			stu.setStuName(rs.getString("stuName"));
			stu.setStuSubject(rs.getString("stuSubject"));
			stu.setStuAge(rs.getInt("stuAge"));
			stu.setStuMajor(rs.getString("stuMajor"));
			list.add(stu);
			}
		} catch (SQLException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public List<Stu> getStuListByStuName(String stuName) {
		List<Stu> list = new ArrayList<>();
		try {
			String sql = "select*from student where stuName=?";
			PreparedStatement prep = conn.prepareStatement(sql);
			prep.setString(1, stuName);
			ResultSet rs = prep.executeQuery();
			while(rs.next()) {
			Stu stu = new Stu();
			stu.setStuId(rs.getString("stuId"));
			stu.setStuName(rs.getString("stuName"));
			stu.setStuSubject(rs.getString("stuSubject"));
			stu.setStuAge(rs.getInt("stuAge"));
			stu.setStuMajor(rs.getString("StuMajor"));
			list.add(stu);
			}
		} catch (SQLException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		
		
		return list;
	}

	@Override
	public int updateStu(Stu stu) {		
		int flag = 0;
		try {
			String sql = "update student set stuName=?,stuSubject=?,stuAge=?,stuMajor=? where stuId=?";
			PreparedStatement prep = conn.prepareStatement(sql);
			prep.setString(1, stu.getStuName());
			prep.setString(2, stu.getStuSubject());
			prep.setInt(3, stu.getStuAge());
			prep.setString(4, stu.getStuMajor());
			prep.setString(5, stu.getStuId());
			flag = prep.executeUpdate();		
		} catch (SQLException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		return flag;
	}

	@Override
	public int deleteStu(String stuId) {		
		int flag = 0;
		try {
			String sql = "delete from student where stuId=?";
			PreparedStatement prep = conn.prepareStatement(sql);
			prep.setString(1,stuId );
			flag = prep.executeUpdate();		
		} catch (SQLException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		return flag;
	}
		
		
	}


