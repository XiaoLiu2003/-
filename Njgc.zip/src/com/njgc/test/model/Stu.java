package com.njgc.test.model;
//对应数据库中的数据
public class Stu {
	private String stuId;
	private String stuName;
	private String stuSubject;
	private int stuAge;
	private String stuMajor;
	
	public Stu(String stuId, String stuName, String stuSubject, int stuAge, String stuMajor) {
		super();
		this.stuId = stuId;
		this.stuName = stuName;
		this.stuAge = stuAge;
		this.setStuMajor(stuMajor);
		this.stuSubject = stuSubject;
	}
	
	public Stu() {
		super();
	}


	public String getStuId() {
		return stuId;
	}
	public void setStuId(String stuid) {
		this.stuId = stuid;
	}
	public String getStuName() {
		return stuName;
	}
	public void setStuName(String stuName) {
		this.stuName = stuName;
	}
	public int getStuAge() {
		return stuAge;
	}
	public void setStuAge(int stuAge) {
		this.stuAge = stuAge;
	}
	public String getStuSubject() {
		return stuSubject;
	}
	public void setStuSubject(String stuSubject) {
		this.stuSubject = stuSubject;
	}

	public String getStuMajor() {
		return stuMajor;
	}

	public void setStuMajor(String stuMajor) {
		this.stuMajor = stuMajor;
	}

	
	

}
