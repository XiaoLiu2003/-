package com.njgc.test.service;

import java.util.List;

import com.njgc.test.model.Stu;

public interface StuService {
	
	public int insertStu(Stu stu);//添加学生选课信息
	/*
	 * @return int
	 * @param stu
	 */

	public List<Stu> getAllStuList();//显示所有学生选课信息
	/*
	 * @return list
	 */

	public Stu getStuByStuId(String stuId);//通过学号查询学生选课信息
	/*
	 * @param stuId
	 * @return Stu
	 */
	public List<Stu> getStuListByStuName(String stuName);//通过姓名查询学生选课信息

	public int updateStu(Stu stu);//根据学号修改学生选课信息
	/*
	 * @param stu
	 * @return
	 */

	public int deleteStu(String stuId);//根据学号删除学生选课信息

}
