package com.njgc.test.service;

import java.util.List;

import com.njgc.test.dao.StuDao;
import com.njgc.test.dao.StuDaoImpl;
import com.njgc.test.model.Stu;
//做业务逻辑处理
public class StuServiceImpl implements StuService{
	StuDao dao = new StuDaoImpl();

	@Override
	public int insertStu(Stu stu) {
		Stu newphone = dao.getStuByStuId(stu.getStuId());
		if(newphone!=null && newphone.getStuId()!=null){
			return -1;
		}else {
			 int flag = dao.insertStu(stu);
			 return flag;
		}
	}

	@Override
	public List<Stu> getAllStuList() {
		// TODO 自动生成的方法存根
		return dao.getAllStuList();
	}

	@Override
	public Stu getStuByStuId(String stuId) {
		// TODO 自动生成的方法存根
		return dao.getStuByStuId(stuId);
	}

	@Override
	public List<Stu> getStuListByStuName(String stuName) {
		// TODO 自动生成的方法存根
		return dao.getStuListByStuName(stuName);
	}

	@Override
	public  int updateStu(Stu stu) {
		
		return dao.updateStu(stu);
	}

	@Override
	public int deleteStu(String stuId) {
		
		return dao.deleteStu(stuId);
	}

}
