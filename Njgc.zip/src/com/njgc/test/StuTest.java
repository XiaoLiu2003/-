package com.njgc.test;
import java.util.List;
import java.util.Scanner;
import com.njgc.test.model.Stu;
import com.njgc.test.service.StuService;
import com.njgc.test.service.StuServiceImpl;

public class StuTest {
	static StuService service = new StuServiceImpl();
	public static void main(String[] args) {
		System.out.println("==============欢迎进入学生选课信息系统===============");
		while(true){//一直是正确的循环
			System.out.println("******************");  	
            System.out.println("请根据提示选择要操作的内容：");
            System.out.println("1-学生选课信息添加");
            System.out.println("2-学生选课信息浏览（显示所有学生选课信息）");
            System.out.println("3-学生选课信息查询（按学号查询和按学生姓名查询 ）");
            System.out.println("4-学生选课信息修改（按学号进行修改学生选课信息）");
            System.out.println("5-学生选课信息删除（按学号进行删除）");
            System.out.println("6-退出）");
            System.out.print("请选择要操作的序号（1-6）:");
            Scanner scanner = new Scanner(System.in);//输入数字
            String flag = scanner.nextLine();
            if(flag.equals("6")){//输入除了1-6之外的序号
            	System.out.println("谢谢使用！");       
                break;
            }
            switch(flag){
            case "1":
            	insertStu();//添加信息
            	break;     
            case "2":
                allStuList();//浏览全部信息
                break;
            case "3":
                searchStu();//查询信息
                break;
            case "4":
                updateStu();//更新修改信息
                break;
           case "5":
                deleteStu();//删除信息
                break;
           default:
                System.out.println("您输入的格式有误，请重新输入");        
         }
      }
}


   private static void deleteStu() {
	   System.out.println("请输入要删除的学号：");
	   Scanner scanner = new Scanner(System.in);
	   String StuId = scanner.nextLine();
	   Stu Stu = service.getStuByStuId(StuId);
	   if(Stu!=null && Stu.getStuId()!=null) {
		   int flag = service.deleteStu(StuId);
		   if(flag>0) {		   
		   System.out.println("学生选课信息删除成功");
		   
	   }else {
		   System.out.println("学生选课信息删除失败");
	   }   
    }else {
    	System.out.println("该学号不存在无法删除");
    }

    }

   private static void updateStu() {
	   System.out.println("请输入要修改的学生学号：");
	   Scanner scanner = new Scanner(System.in);
	   String stuId = scanner.nextLine();
	   Stu Stu = service.getStuByStuId(stuId);
	   if(Stu!=null && Stu.getStuId()!=null) {
		   System.out.println( "输入学生选课信息如下：姓名,选课内容,年龄,专业。各字段以,隔开。具体格式如下：刘伟，离散数学，21，软件工程");
		   System.out.print("请输入学生选课要修改的信息：");
	       String strStu = scanner.nextLine();
	       String[] arrStu = strStu.split(",|，");
	       int stuAge = Integer.valueOf(arrStu[2]);
	       Stu updateStu = new Stu(stuId,arrStu[0],arrStu[1],stuAge,arrStu[3]);
	       int status = service.updateStu(updateStu);
	       if(status>0) {
	    	   System.out.println("学生选课信息修改成功");
	    	   System.out.println("修改后的选课信息如下：");
	    	   System.out.println("学号:"+updateStu.getStuId()+"\t"+"姓名:"+updateStu.getStuName()+"\t"+
					   "选课内容:"+updateStu.getStuSubject()+"\t"+"学生年龄:"+updateStu.getStuAge()+"\t"+"学生专业:"+updateStu.getStuMajor()+"\t");	   
		   }
	       
	   }else {
		   System.out.println("学生选课信息修改失败");
		   System.out.println("学号不存在");
	   }}

   private static void searchStu() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("1-按学号查询 2-按学生姓名查询");
		System.out.println("请输入（1或者2）:");
		String flag = scanner.nextLine();
		switch(flag){
		  case "1":
			  searchByStuId();
			  break;
		  case "2":
			  searchByStuName();
			  break;
	      default:
		      System.out.println("格式有误");
		}
		
	}




    private static void searchByStuName() {
    	System.out.print("请输入学生姓名：");
		Scanner scanner = new Scanner(System.in);
		String stuName = scanner.nextLine();
		List<Stu> list = service.getStuListByStuName(stuName);
		if(list!=null && list.size()>0){
			 for(Stu stu:list) {
				   System.out.println("学号:"+stu.getStuId()+"\t"+"姓名:"+stu.getStuName()+"\t"+
						   "选课:"+stu.getStuSubject()+"\t"+"学生年龄:"+stu.getStuAge()+"\t"+"学生专业:"+stu.getStuMajor()+"\t");	   
			   }
			 }else {
				 System.out.println("暂无该姓名学生选课信息");
			 }
		}

    private static void searchByStuId() {
    	System.out.print("请输入学生学号：");
		Scanner scanner = new Scanner(System.in);
		String stuId = scanner.nextLine();
		Stu stu = service.getStuByStuId(stuId);
		System.out.println("该学生选课信息显示如下：");
		if(stu==null || stu.getStuId()==null) {
			System.out.println("该学号没有对应学生，未查到学生选课信息");
		}else {
			 System.out.println("学号:"+stu.getStuId()+"\t"+"姓名:"+stu.getStuName()+"\t"+
					   "选课:"+stu.getStuSubject()+"\t"+"学生年龄:"+stu.getStuAge()+"\t"+"学生专业:"+stu.getStuMajor()+"\t");	

		}
	
   }
    
    
    
   private static void allStuList() {
	   System.out.println("所有学生选课信息如下:");
	   List<Stu> list = service.getAllStuList();
	   if(list!=null && list.size()>0){
	   for(Stu stu:list) {
		   System.out.println("学号:"+stu.getStuId()+"\t"+"姓名:"+stu.getStuName()+"\t"+
				   "选课:"+stu.getStuSubject()+"\t"+"学生年龄:"+stu.getStuAge()+"\t"+"学生专业:"+stu.getStuMajor()+"\t");		   
	   }
	 }else {
		 System.out.println("暂无学生选课信息");
	 }
}

   private static void insertStu() {
       Scanner scanner = new Scanner(System.in);
       System.out.println( "输入学生选课信息如下：学号,姓名,选课内容,年龄,专业。各字段以,隔开。具体格式如下：10,刘伟，离散数学，21，软件工程");
       System.out.print("请输入学生选课信息：");
       String strStu = scanner.nextLine();
       String[] arrStu = strStu.split(",|，");
       int stuAge = Integer.valueOf(arrStu[3]);
       Stu stu = new Stu(arrStu[0],arrStu[1],arrStu[2],stuAge,arrStu[4]);
       int status = service.insertStu(stu);
       if(status>0){
       System.out.println("学生选课信息添加成功");
       }else if(status==0){
       System.out.println("学生选课信息添加失败");
       }else{
        System.out.println("学生选课信息已存在， 添加失败。");
     }
    }
}